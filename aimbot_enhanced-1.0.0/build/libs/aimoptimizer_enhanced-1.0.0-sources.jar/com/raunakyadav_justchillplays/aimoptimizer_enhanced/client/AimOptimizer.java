package com.raunakyadav_justchillplays.aimoptimizer_enhanced.client;

import com.raunakyadav_justchillplays.aimoptimizer_enhanced.ModState;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public class AimOptimizer {
    private static final double RANGE = 10.0;
    private static final double FOV = 45.0;

    public static void tick(class_310 client) {
        if (!ModState.isEnabled() || client.field_1724 == null || client.field_1687 == null) {
            return;
        }

        class_1297 target = findTarget(client);
        if (target != null) {
            lockToTarget(client, target);
        }
    }

    private static class_1297 findTarget(class_310 client) {
        class_1657 player = client.field_1724;
        class_243 eyePos = player.method_33571();
        class_243 lookVec = player.method_5828(1.0F);

        List<class_1309> targets = client.field_1687.method_8390(class_1309.class, 
            player.method_5829().method_1014(RANGE), 
            entity -> entity != player && entity.method_5805());

        return targets.stream()
            .filter(entity -> {
                class_243 targetPos = entity.method_33571();
                class_243 toTarget = targetPos.method_1020(eyePos).method_1029();
                double dot = lookVec.method_1026(toTarget);
                double angle = Math.acos(dot) * (180 / Math.PI);
                return angle < FOV;
            })
            .min(Comparator.comparingDouble(entity -> entity.method_5739(player)))
            .orElse(null);
    }

    private static void lockToTarget(class_310 client, class_1297 target) {
        class_1657 player = client.field_1724;
        class_243 eyePos = player.method_33571();
        class_243 targetPos = target.method_5829().method_1005(); // Aim at center

        double dx = targetPos.field_1352 - eyePos.field_1352;
        double dy = targetPos.field_1351 - eyePos.field_1351;
        double dz = targetPos.field_1350 - eyePos.field_1350;
        double dist = Math.sqrt(dx * dx + dz * dz);

        float targetYaw = (float) (class_3532.method_15349(dz, dx) * (180 / Math.PI)) - 90.0F;
        float targetPitch = (float) (-(class_3532.method_15349(dy, dist) * (180 / Math.PI)));

        float strength = ModState.getMode() == ModState.AimMode.ENHANCED ? 0.3F : 0.15F;

        player.method_36456(lerpAngle(player.method_36454(), targetYaw, strength));
        player.method_36457(lerpAngle(player.method_36455(), targetPitch, strength));
    }

    private static float lerpAngle(float start, float end, float pct) {
        float diff = class_3532.method_15393(end - start);
        return start + diff * pct;
    }
}
