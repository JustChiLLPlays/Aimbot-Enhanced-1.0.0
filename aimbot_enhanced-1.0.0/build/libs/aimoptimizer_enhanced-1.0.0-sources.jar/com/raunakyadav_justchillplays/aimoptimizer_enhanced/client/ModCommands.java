package com.raunakyadav_justchillplays.aimoptimizer_enhanced.client;

import com.mojang.brigadier.CommandDispatcher;
import com.raunakyadav_justchillplays.aimoptimizer_enhanced.ModState;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.class_124;
import net.minecraft.class_2561;

public class ModCommands {
    public static void register(CommandDispatcher<FabricClientCommandSource> dispatcher) {
        dispatcher.register(ClientCommandManager.literal("aimoptimizer")
            .then(ClientCommandManager.literal("enable").executes(context -> {
                ModState.setEnabled(true);
                context.getSource().sendFeedback(class_2561.method_43470("AimOptimizer_Enhanced ENABLED").method_27692(class_124.field_1060));
                return 1;
            }))
            .then(ClientCommandManager.literal("disable").executes(context -> {
                ModState.setEnabled(false);
                context.getSource().sendFeedback(class_2561.method_43470("AimOptimizer_Enhanced DISABLED").method_27692(class_124.field_1061));
                return 1;
            }))
            .then(ClientCommandManager.literal("help").executes(context -> {
                context.getSource().sendFeedback(class_2561.method_43470("=== AimOptimizer_Enhanced Help ===").method_27692(class_124.field_1054));
                context.getSource().sendFeedback(class_2561.method_43470("/aimoptimizer enable - Enable the mod"));
                context.getSource().sendFeedback(class_2561.method_43470("/aimoptimizer disable - Disable the mod"));
                context.getSource().sendFeedback(class_2561.method_43470("/aimoptimizer help - Show this message"));
                context.getSource().sendFeedback(class_2561.method_43470("/aimoptimizer about - About the mod"));
                context.getSource().sendFeedback(class_2561.method_43470("/aimoptimizer Developer - Show developer info"));
                return 1;
            }))
            .then(ClientCommandManager.literal("about").executes(context -> {
                context.getSource().sendFeedback(class_2561.method_43470("AimOptimizer_Enhanced: A TRUE UNFAIR CHEAT.").method_27695(class_124.field_1061, class_124.field_1067));
                return 1;
            }))
            .then(ClientCommandManager.literal("Developer").executes(context -> {
                context.getSource().sendFeedback(class_2561.method_43470("Developer: RaunakAkaJustChiLL").method_27692(class_124.field_1075));
                return 1;
            }))
        );
    }
}
