package com.raunakyadav_justchillplays.aimoptimizer_enhanced.client;

import com.raunakyadav_justchillplays.aimoptimizer_enhanced.ModState;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class ModMenuScreen extends class_437 {
    private final class_437 parent;

    public ModMenuScreen(class_437 parent) {
        super(class_2561.method_43470("AimOptimizer_Enhanced Menu"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int centerX = this.field_22789 / 2;
        int startY = 60;
        int buttonWidth = 200;
        int buttonHeight = 20;
        int spacing = 24;

        // Enable/Disable Toggle
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470(ModState.isEnabled() ? "Disable" : "Enable"),
                button -> {
                    ModState.setEnabled(!ModState.isEnabled());
                    this.method_41843();
                })
                .method_46434(centerX - buttonWidth / 2, startY, buttonWidth, buttonHeight)
                .method_46431());

        // Normal Aim
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Normal Aim").method_27692(ModState.getMode() == ModState.AimMode.NORMAL ? class_124.field_1054 : class_124.field_1068),
                button -> {
                    ModState.setMode(ModState.AimMode.NORMAL);
                    this.method_41843();
                })
                .method_46434(centerX - buttonWidth / 2, startY + spacing, buttonWidth, buttonHeight)
                .method_46431());

        // Enhanced Aim
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Enhanced Aim").method_27692(ModState.getMode() == ModState.AimMode.ENHANCED ? class_124.field_1054 : class_124.field_1068),
                button -> {
                    ModState.setMode(ModState.AimMode.ENHANCED);
                    this.method_41843();
                })
                .method_46434(centerX - buttonWidth / 2, startY + spacing * 2, buttonWidth, buttonHeight)
                .method_46431());

        // About Mod
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("About Mod"),
                button -> {
                    if (this.field_22787 != null) {
                        this.field_22787.method_1507(new AboutModScreen(this));
                    }
                })
                .method_46434(centerX - buttonWidth / 2, startY + spacing * 3, buttonWidth, buttonHeight)
                .method_46431());

        // Show Help
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Show Help"),
                button -> {
                    if (this.field_22787 != null) {
                        this.field_22787.method_1507(new HelpScreen(this));
                    }
                })
                .method_46434(centerX - buttonWidth / 2, startY + spacing * 4, buttonWidth, buttonHeight)
                .method_46431());

        // Close Menu
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Close Menu"),
                button -> this.method_25419())
                .method_46434(centerX - buttonWidth / 2, startY + spacing * 5, buttonWidth, buttonHeight)
                .method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 20, 0xFFFFFF);
    }

    @Override
    public void method_25419() {
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.parent);
        }
    }

    // Simple Help Screen
    public static class HelpScreen extends class_437 {
        private final class_437 parent;

        public HelpScreen(class_437 parent) {
            super(class_2561.method_43470("Help"));
            this.parent = parent;
        }

        @Override
        protected void method_25426() {
            this.method_37063(class_4185.method_46430(class_2561.method_43470("Back"), button -> this.method_25419())
                .method_46434(this.field_22789 / 2 - 100, this.field_22790 - 40, 200, 20)
                .method_46431());
        }

        @Override
        public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
            super.method_25394(context, mouseX, mouseY, delta);
            context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 20, 0xFFFFFF);
            int y = 50;
            context.method_25300(this.field_22793, "1. Enable the mod to start optimizing your aim.", this.field_22789 / 2, y, 0xAAAAAA);
            context.method_25300(this.field_22793, "2. Choose between Normal and Enhanced mode.", this.field_22789 / 2, y + 15, 0xAAAAAA);
            context.method_25300(this.field_22793, "3. Enhanced mode has stronger lock strength.", this.field_22789 / 2, y + 30, 0xAAAAAA);
        }

        @Override
        public void method_25419() {
            if (this.field_22787 != null) this.field_22787.method_1507(parent);
        }
    }

    // Simple About Mod Screen
    public static class AboutModScreen extends class_437 {
        private final class_437 parent;

        public AboutModScreen(class_437 parent) {
            super(class_2561.method_43470("About Mod"));
            this.parent = parent;
        }

        @Override
        protected void method_25426() {
            this.method_37063(class_4185.method_46430(class_2561.method_43470("Back"), button -> this.method_25419())
                .method_46434(this.field_22789 / 2 - 100, this.field_22790 - 40, 200, 20)
                .method_46431());
        }

        @Override
        public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
            super.method_25394(context, mouseX, mouseY, delta);
            context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 20, 0xFFFFFF);
            int y = 50;
            context.method_25300(this.field_22793, "AimOptimizer_Enhanced", this.field_22789 / 2, y, 0xFF5555);
            context.method_25300(this.field_22793, "This mod is a TRUE UNFAIR CHEAT.", this.field_22789 / 2, y + 20, 0xFF0000);
            context.method_25300(this.field_22793, "Use it at your own risk!", this.field_22789 / 2, y + 40, 0xFF0000);
            context.method_25300(this.field_22793, "Developer: RaunakAkaJustChiLL", this.field_22789 / 2, y + 70, 0x55FFFF);
        }

        @Override
        public void method_25419() {
            if (this.field_22787 != null) this.field_22787.method_1507(parent);
        }
    }
}
