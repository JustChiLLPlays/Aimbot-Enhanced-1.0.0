package com.raunakyadav_justchillplays.aimoptimizer_enhanced.mixin.client;

import com.raunakyadav_justchillplays.aimoptimizer_enhanced.client.ModMenuScreen;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_433;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_433.class)
public abstract class GameMenuScreenMixin extends class_437 {
    protected GameMenuScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method = "init", at = @At("RETURN"))
    private void addAimOptimizerButton(CallbackInfo ci) {
        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("AimOptimizer_Enhanced"),
                button -> {
                    if (this.field_22787 != null) {
                        this.field_22787.method_1507(new ModMenuScreen(this));
                    }
                })
                .method_46434(this.field_22789 - 160, 10, 150, 20)
                .method_46431());
    }
}
